import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class getStarted extends StatelessWidget {
  const getStarted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
